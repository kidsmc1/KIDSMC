KIDS MC — REAL AI + SUPABASE EDGE FUNCTION

This ZIP contains the KIDS MC website with a real AI chat connected through
a Supabase Edge Function.

SETUP:
1. Deploy the function:
   supabase/functions/kids-mc-ai/index.ts
   Function name: kids-mc-ai

2. In Supabase Edge Function Secrets, add:
   OPENAI_API_KEY = your private OpenAI API key

3. Keep JWT verification enabled.

4. In public/index.html, replace:
   PASTE_YOUR_SUPABASE_PROJECT_URL
   PASTE_YOUR_SUPABASE_ANON_KEY
   with your Supabase project URL and Publishable/Anon key.

5. Deploy the public/ folder to Netlify.

IMPORTANT:
- Never put OPENAI_API_KEY in index.html.
- Never expose a Supabase service-role/secret key in the browser.
- Users must log in/register before using KIDS MC AI.

Server: KIDSMC.XYZ
Discord: https://discord.gg/ZW3BF3VRug


KIDS MC updates:
- Smooth blue theme and animated floating particles.
- Media Requirements + Media Apply form.
- Staff Apply form with the 9 exact questions supplied by the owner.
- Admin Power must be implemented with server-side/Supabase authentication; never store the admin password in frontend code.
